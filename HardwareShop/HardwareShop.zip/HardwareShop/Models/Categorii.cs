﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HardwareShop.Models
{
    public class Categorie
    {
        public byte Id { get; set; }
        public string Nume { get; set; }
    }
}