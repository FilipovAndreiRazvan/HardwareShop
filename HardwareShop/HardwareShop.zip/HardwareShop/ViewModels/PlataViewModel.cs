﻿using HardwareShop.Models;

namespace HardwareShop.ViewModels
{
    public class PlataViewModel
    {
        public Comanda comanda;
        public Card card;

    }
}